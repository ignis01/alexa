module.exports.states = {
    STARTMODE: '_STARTMODE',  // Prompt the user to start or restart the app.
    FAQMODE: '_FAQMODE',
    FXMODE: '_FXMODE',
    BANKACCMODE: '_BANKACCMODE',
    CREDITCARDMODE: '_CREDITCARDMODE',
    LOCATIONMODE: '_LOCATIONMODE'
};