/**
 * Created by YiLiang on 2017-08-08.
 */
module.exports.goodbyeResponse = 'Thank for using B. M. O. next, Goodbye!';
module.exports.errorResponse = "I don't understand your request, please Say Help for assistance or Start Over to retry";
module.exports.helpGreeting = 'Welcome to B.M.O. Next. How can I help you? Say Foreign Exchange for FX rate information. ' +
    'Say Bank Account for our day to day banking information. Say Credit Card for our credit card information. ' +
    'Say Branch for our Branch Location Search. Say I have a Question to access to our Frequently Asked Questions ';
module.exports.notImplementedResponse = "Sorry, this function has not been implemented yet, what else can I do for you?";
